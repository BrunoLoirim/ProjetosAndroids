package faculdadedelta.edu.exercicio3brunodias;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class PrincipalActivity extends AppCompatActivity {

    private EditText etProduto;
    private EditText etValor;
    private EditText etCliente;
    private EditText etDataVenda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        etProduto = findViewById(R.id.etProduto);
        etValor = findViewById(R.id.etValor);
        etCliente = findViewById(R.id.etCliente);
        etDataVenda = findViewById(R.id.etDataVenda);
    }

    public void vender(View view) {
        Intent intent = new Intent(getBaseContext(), ValidacaoActivity.class);

        intent.putExtra("produtoParam", etProduto.getText().toString());
        intent.putExtra("valorParam", etValor.getText().toString());
        intent.putExtra("clienteParam", etCliente.getText().toString());
        intent.putExtra("dataVendaParam", etDataVenda.getText().toString());
    }

    public void limpar(View view) {
        etProduto.setText("");
        etValor.setText("");
        etCliente.setText("");
        etDataVenda.setText("");
    }
}
