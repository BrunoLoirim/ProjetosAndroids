package faculdadedelta.edu.trabalho1n2brunodias;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ItemListaDiarias extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_lista_diarias);
    }
}
